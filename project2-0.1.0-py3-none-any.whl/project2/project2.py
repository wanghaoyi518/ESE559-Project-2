import numpy as np

def clip(n, minn, maxn):
    return max(min(maxn, n), minn)

def dynamics(xv, uv, ts=1):
    res = np.zeros_like(xv)
    tmp = uv[1] * ts / 2 + 1e-6
    sinc = np.divide(np.sin(tmp * np.pi), (tmp * np.pi))
    cal = np.multiply(uv[0], sinc)
    tmpx = np.multiply(cal, np.cos(xv[2] + tmp))
    tmpy = np.multiply(cal, np.sin(xv[2] + tmp))
    res[0] = xv[0] + tmpx
    res[1] = xv[1] + tmpy
    res[2] = xv[2] + ts * uv[1]
    return res

def move(state, action):
    x, y, theta = state 
    xv = [x, y, theta]
    ws_size = 1.5 
    uv = action
    noise_v = np.random.normal(0, 0.001)
    if -0.3 < x < 0.3 and -0.3 < y < 0.3:
        noise_w = np.random.normal(0, 0.5)
    elif -1 < x < 0.5 and -0.3 < y < 0.3:
        noise_w = np.random.normal(0, 0.3)
    elif x > 0.3:
        noise_w = np.random.normal(0, 0.02)
    elif x < -0.3:
        noise_w = np.random.normal(0, 0.0001)
    else:
        noise_w = np.random.normal(0, 0.01)
    uv0 = clip(uv[0] + noise_v, -0.26, 0.26)
    uv1 = clip(uv[1] + noise_w, -1.82, 1.82)
    uv = [uv0, uv1]
    state_next = dynamics(xv, uv)
    xp = clip(state_next[0], -ws_size, ws_size)
    yp = clip(state_next[1], -ws_size, ws_size)
    tp = clip(state_next[2], -np.pi, np.pi)
    next_x = [xp, yp, tp]
    return next_x